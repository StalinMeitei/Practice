import { useEffect, useState } from 'react'
import {
  Box,
  Grid,
  Paper,
  Typography,
  Card,
  CardContent,
  Avatar,
} from '@mui/material'
import {
  TrendingUp,
  TrendingDown,
  People,
  VpnKey,
  Message,
  CheckCircle,
} from '@mui/icons-material'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import axios from 'axios'

const StatCard = ({ title, value, change, icon, color }) => (
  <Card sx={{ height: '100%' }}>
    <CardContent sx={{ p: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <Box sx={{ flex: 1 }}>
          <Typography color="textSecondary" variant="overline" sx={{ fontSize: 11, lineHeight: 1.2 }}>
            {title}
          </Typography>
          <Typography variant="h5" sx={{ mt: 0.5, mb: 0.5, fontWeight: 600 }}>
            {value}
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            {change >= 0 ? (
              <TrendingUp sx={{ fontSize: 14, color: 'success.main', mr: 0.5 }} />
            ) : (
              <TrendingDown sx={{ fontSize: 14, color: 'error.main', mr: 0.5 }} />
            )}
            <Typography
              variant="body2"
              sx={{ color: change >= 0 ? 'success.main' : 'error.main', fontSize: 12 }}
            >
              {Math.abs(change)}%
            </Typography>
          </Box>
        </Box>
        <Avatar sx={{ bgcolor: color, width: 40, height: 40 }}>
          {icon}
        </Avatar>
      </Box>
    </CardContent>
  </Card>
)

export default function Dashboard() {
  const [stats, setStats] = useState({
    partners: 0,
    keys: 0,
    messages: 0,
    successRate: 0,
  })

  const messageData = [
    { month: 'Jan', messages: 65 },
    { month: 'Feb', messages: 59 },
    { month: 'Mar', messages: 80 },
    { month: 'Apr', messages: 81 },
    { month: 'May', messages: 56 },
    { month: 'Jun', messages: 55 },
    { month: 'Jul', messages: 40 },
    { month: 'Aug', messages: 95 },
    { month: 'Sep', messages: 120 },
    { month: 'Oct', messages: 140 },
    { month: 'Nov', messages: 160 },
    { month: 'Dec', messages: 150 },
  ]

  const statusData = [
    { name: 'Success', value: 85, color: '#10B981' },
    { name: 'Pending', value: 10, color: '#F59E0B' },
    { name: 'Failed', value: 5, color: '#EF4444' },
  ]

  useEffect(() => {
    // Fetch stats from API
    const fetchStats = async () => {
      try {
        // Mock data for now
        setStats({
          partners: 12,
          keys: 24,
          messages: 1847,
          successRate: 95.5,
        })
      } catch (error) {
        console.error('Error fetching stats:', error)
      }
    }
    fetchStats()
  }, [])

  return (
    <Box>
      <Typography variant="h5" sx={{ mb: 2, fontWeight: 600 }}>
        Overview
      </Typography>

      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="TOTAL PARTNERS"
            value={stats.partners}
            change={12}
            icon={<People />}
            color="#10B981"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="ACTIVE KEYS"
            value={stats.keys}
            change={8}
            icon={<VpnKey />}
            color="#F59E0B"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="MESSAGES"
            value={stats.messages}
            change={-5}
            icon={<Message />}
            color="#5048E5"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="SUCCESS RATE"
            value={`${stats.successRate}%`}
            change={2.5}
            icon={<CheckCircle />}
            color="#06B6D4"
          />
        </Grid>

        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <Typography variant="h6" sx={{ fontWeight: 600, fontSize: 16 }}>
                Messages
              </Typography>
            </Box>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={messageData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" style={{ fontSize: 12 }} />
                <YAxis style={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="messages" fill="#5048E5" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" sx={{ fontWeight: 600, mb: 2, fontSize: 16 }}>
              Message Status
            </Typography>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <Box sx={{ mt: 1 }}>
              {statusData.map((item) => (
                <Box
                  key={item.name}
                  sx={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    mb: 0.5,
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Box
                      sx={{
                        width: 10,
                        height: 10,
                        borderRadius: '50%',
                        bgcolor: item.color,
                        mr: 1,
                      }}
                    />
                    <Typography variant="body2" sx={{ fontSize: 13 }}>{item.name}</Typography>
                  </Box>
                  <Typography variant="body2" sx={{ fontWeight: 600, fontSize: 13 }}>
                    {item.value}%
                  </Typography>
                </Box>
              ))}
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  )
}
